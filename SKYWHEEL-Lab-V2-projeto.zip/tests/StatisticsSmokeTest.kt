import com.skywheel.lab.*
fun main() {
    val now = System.currentTimeMillis()
    val rows = listOf(
        Observation(1, "Símbolo A", now, "simulado"),
        Observation(2, "Símbolo A", now + 1000, "simulado"),
        Observation(3, "Símbolo B", now + 2000, "simulado")
    )
    check("Total: 3" in Statistics.summary(rows))
    check("Símbolo A: 2 (66,7%)" in Statistics.summary(rows))
    check("Símbolo A → Símbolo A: 1" in Statistics.detailed(rows))
    check(Statistics.csv(rows).lineSequence().count { it.isNotBlank() } == 4)
    println("OK")
}
