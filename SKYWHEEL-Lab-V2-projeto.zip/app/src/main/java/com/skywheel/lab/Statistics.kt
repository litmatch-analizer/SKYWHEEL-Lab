package com.skywheel.lab

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

/** Descrição de frequências observadas, NÃO predição da próxima rodada. */
object Statistics {
    private fun fmt(timestamp: Long, pattern: String): String = SimpleDateFormat(pattern, Locale.forLanguageTag("pt-BR")).format(Date(timestamp))

    fun summary(rows: List<Observation>): String {
        if (rows.isEmpty()) return "Nenhum resultado registrado ainda.\nToque em um símbolo para adicionar uma observação."
        val counts = Symbols.all.associateWith { symbol -> rows.count { it.symbol == symbol } }
        val last = rows.last()
        val top = counts.entries.sortedWith(compareByDescending<Map.Entry<String,Int>> { it.value }.thenBy { it.key })
        val topText = top.take(4).joinToString("\n") { (symbol, n) ->
            val p = 100.0 * n / rows.size
            "${Symbols.emoji[symbol] ?: ""} $symbol: $n (%.1f%%)".format(Locale.forLanguageTag("pt-BR"), p)
        }
        val hour = Calendar.getInstance().apply { timeInMillis = System.currentTimeMillis() }.get(Calendar.HOUR_OF_DAY)
        val sameHour = rows.filter { Calendar.getInstance().apply { timeInMillis = it.timestamp }.get(Calendar.HOUR_OF_DAY) == hour }
        val inHour = if (sameHour.size < 20) "Amostra pequena (${sameHour.size}) para comparar horários." else {
            val lead = Symbols.all.maxByOrNull { s -> sameHour.count { it.symbol == s } }!!
            "Nesta hora: $lead foi ${sameHour.count { it.symbol == lead }}/${sameHour.size} observações."
        }
        return "Total: ${rows.size}\nÚltimo: ${Symbols.emoji[last.symbol]} ${last.symbol}, ${fmt(last.timestamp, "dd/MM HH:mm:ss")}\n\nFrequência observada:\n$topText\n\n$inHour\n\nCoincidências não garantem o próximo resultado."
    }

    fun detailed(rows: List<Observation>): String {
        if (rows.isEmpty()) return "Nenhuma observação ainda."
        val sb = StringBuilder(summary(rows)).append("\n\n--- INTERVALOS POR SÍMBOLO ---\n")
        for (symbol in Symbols.all) {
            val timestamps = rows.filter { it.symbol == symbol }.map { it.timestamp }
            val intervals = timestamps.zipWithNext { a, b -> (b - a) / 60000.0 }
            val avg = if (intervals.isNotEmpty()) "%.1f min".format(Locale.forLanguageTag("pt-BR"), intervals.average()) else "sem dados"
            sb.append("$symbol: ${timestamps.size} vezes; intervalo médio $avg\n")
        }
        sb.append("\n--- MESMO MINUTO EM DIAS DIFERENTES ---\n")
        // HH:mm reúne eventos de dias diferentes apenas para descrição, sem inferir causalidade.
        val groups = rows.groupBy { "${it.symbol} às ${fmt(it.timestamp, "HH:mm")}" }
        val repeating = groups.filter { (_, rs) -> rs.map { fmt(it.timestamp, "yyyy-MM-dd") }.distinct().size >= 2 }
        if (repeating.isEmpty()) sb.append("Ainda não há coincidências desse tipo.\n")
        else repeating.entries.sortedByDescending { it.value.size }.take(6).forEach { (key, rs) ->
            val days = rs.map { fmt(it.timestamp, "yyyy-MM-dd") }.distinct().size
            sb.append("$key — $days dias diferentes\n")
        }
        sb.append("\n--- TRANSIÇÕES MAIS FREQUENTES ---\n")
        val pairs = rows.zipWithNext { a,b -> "${a.symbol} → ${b.symbol}" }.groupingBy { it }.eachCount()
        pairs.entries.sortedByDescending { it.value }.take(6).forEach { sb.append("${it.key}: ${it.value} vezes\n") }
        sb.append("\nObservações em horários populares podem refletir maior número de rodadas. Não são previsões.\n")
        return sb.toString()
    }

    fun csv(rows: List<Observation>): String {
        val out = StringBuilder("id,data_iso_local,simbolo,origem\r\n")
        rows.forEach { r ->
            val date = fmt(r.timestamp, "yyyy-MM-dd'T'HH:mm:ssZ")
            out.append(r.id).append(',').append(date).append(',')
                .append('"').append(r.symbol.replace("\"", "\"\"")).append('"').append(',')
                .append(r.source).append("\r\n")
        }
        return out.toString()
    }
}
