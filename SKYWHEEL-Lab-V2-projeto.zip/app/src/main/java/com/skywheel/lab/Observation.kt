package com.skywheel.lab

data class Observation(val id: Long, val symbol: String, val timestamp: Long, val source: String)
