package com.skywheel.lab

object Symbols {
    val all = (1..8).map { "Símbolo ${'A' + it - 1}" }
    val emoji = all.zip(listOf("🔴", "🔵", "🟢", "🟡", "🟣", "🟠", "⚪", "⚫")).toMap()
    val rarity = listOf("Não definida", "Comum", "Raro", "Muito raro")
}
