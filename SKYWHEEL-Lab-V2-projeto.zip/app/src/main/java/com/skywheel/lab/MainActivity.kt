package com.skywheel.lab

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.security.SecureRandom

/** Laboratório educativo. Não lê aplicativos de terceiros nem faz apostas. */
class MainActivity : Activity() {
    private lateinit var db: HistoryDb
    private lateinit var summary: TextView
    private val random = SecureRandom()
    private val dark = Color.rgb(13, 23, 42)
    private val accent = Color.rgb(45, 104, 221)

    private fun dp(value: Int) = (resources.displayMetrics.density * value).toInt()
    private fun text(s: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        setPadding(dp(3), dp(7), dp(3), dp(7))
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun button(s: String, f: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(7) }
    }
    private fun simulate(n: Int) {
        val samples = List(n) { Symbols.all[random.nextInt(Symbols.all.size)] }
        db.insertSimulatedBatch(samples)
        update()
        Toast.makeText(this, "$n resultados simulados", Toast.LENGTH_SHORT).show()
    }
    private fun update() {
        summary.text = Statistics.detailed(db.all()) + "\n---\nSão dados fictícios. Um horário coincidente não antecipa o próximo símbolo."
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = HistoryDb(this)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        val scroller = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        scroller.addView(root)
        root.addView(text("SKYWHEEL Lab", 27f, true))
        root.addView(text("Laboratório de padrões aleatórios", 17f, false, Color.rgb(174, 195, 229)))
        root.addView(text("Simule 8 símbolos e observe frequências, repetições, intervalos e coincidências. Não acessa o Litmatch nem tenta prever prêmios.", 13f, false, Color.rgb(174, 195, 229)))
        root.addView(button("Simular 1 resultado") { simulate(1) })
        root.addView(button("Simular 10 resultados") { simulate(10) })
        root.addView(button("Simular 100 resultados") { simulate(100) })
        root.addView(button("Simular 1.000 resultados") { simulate(1000) })
        root.addView(button("Desfazer o último resultado") { db.removeLast(); update() })
        root.addView(button("Exportar dados simulados em CSV") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, "skywheel-simulacao.csv")
            }, 402)
        })
        root.addView(button("Limpar simulação") {
            AlertDialog.Builder(this).setTitle("Recomeçar?")
                .setMessage("Todos os resultados simulados serão apagados.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpar") { _,_ -> db.clear(); update() }.show()
        })
        root.addView(text("ESTATÍSTICAS DA SIMULAÇÃO", 15f, true))
        summary = text("", 14f)
        root.addView(summary)
        setContentView(scroller)
        update()
    }
    @Deprecated("Platform document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 402 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(Statistics.csv(db.all()))
            }
            Toast.makeText(this, "CSV salvo", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro de exportação: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
