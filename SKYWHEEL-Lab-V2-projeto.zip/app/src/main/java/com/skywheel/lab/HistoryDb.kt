package com.skywheel.lab

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Registros locais; nenhuma imagem é gravada ou enviada. */
class HistoryDb(context: Context) : SQLiteOpenHelper(context, "skywheel_lab.sqlite", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE observations (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, happened_at INTEGER NOT NULL, source TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_observations_date ON observations(happened_at)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun insert(symbol: String, source: String = "manual") {
        require(symbol in Symbols.all)
        val args = android.content.ContentValues().apply {
            put("symbol", symbol)
            put("happened_at", System.currentTimeMillis())
            put("source", source)
        }
        writableDatabase.insertOrThrow("observations", null, args)
    }

    @Synchronized
    fun insertSimulatedBatch(symbols: List<String>) {
        require(symbols.all { it in Symbols.all })
        val db = writableDatabase
        db.beginTransaction()
        try {
            val time = System.currentTimeMillis()
            symbols.forEachIndexed { index, symbol ->
                val values = android.content.ContentValues().apply {
                    put("symbol", symbol)
                    put("happened_at", time + index)
                    put("source", "simulado")
                }
                db.insertOrThrow("observations", null, values)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized
    fun all(): List<Observation> {
        val result = mutableListOf<Observation>()
        readableDatabase.rawQuery("SELECT id, symbol, happened_at, source FROM observations ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) result.add(Observation(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3)))
        }
        return result
    }

    @Synchronized
    fun removeLast(): Boolean {
        val id = readableDatabase.rawQuery("SELECT id FROM observations ORDER BY id DESC LIMIT 1", null).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        } ?: return false
        return writableDatabase.delete("observations", "id=?", arrayOf(id.toString())) > 0
    }

    @Synchronized
    fun clear() { writableDatabase.delete("observations", null, null) }
}
