# SKYWHEEL Lab — estatísticas de oito símbolos

Este é um protótipo educacional **independente**, que roda sorteios virtuais com `SecureRandom` e mostra como surgem coincidências de horários, intervalos e sequências mesmo quando todos os resultados têm a mesma chance.

- Não lê a tela nem se sobrepõe a outros aplicativos.
- Não faz apostas, não acessa Litmatch e não oferece previsões de ganhos.
- Guarda dados **fictícios** localmente no SQLite.
- Simula 1, 10, 100 ou 1000 resultados por toque.
- Mostra frequência relativa, transições, intervalos e padrões coincidentes.
- Permite desfazer, limpar e exportar CSV.

## Gerar APK no GitHub

Envie **todos os arquivos deste ZIP** à raiz de um repositório GitHub. Depois abra `Actions` > `Compilar SKYWHEEL-Lab` > `Run workflow`. A compilação gera o artefato `SKYWHEEL-Lab-v2-debug` com o APK.

O projeto foi validado para sintaxe de XML e lógica de estatísticas com testes Kotlin. **Não foi compilado em Android** neste ambiente porque o Android SDK não está instalado.
